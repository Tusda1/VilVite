let bodyel = document.querySelector("body")

let divi = document.createElement("div")

let h = document.createElement("h1")
h.innerHTML = "This is my website"
divi.appendChild(h)

let p = document.createElement("p")
p.setAttribute("id","forste")
p.innerHTML = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim assumenda blanditiis id rem odit tempora ipsa. Earum nemo distinctio omnis quos veniam! Ex, assumenda? Labore, iure illo error vel maxime maiores ad officiis nulla aliquam quos vitae ut eaque nostrum voluptatum beatae alias amet consectetur corrupti laudantium quod saepe tenetur"
divi.appendChild(p)

p = document.createElement("p")
p.setAttribute("id", "andre")
p.innerHTML = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta sapiente incidunt, corporis odio error itaque amet corrupti dignissimos excepturi accusamus culpa nulla magnam molestias enim dolorum rerum suscipit! Est quidem quia earum quam nulla magni mollitia voluptatibus consequuntur neque eaque temporibus labore enim aspernatur perferendis, dicta ea aperiam at, eligendi consectetur ad reprehenderit. Nisi cumque maiores id enim quia odio?"
divi.appendChild(p)

bodyel.appendChild(divi)